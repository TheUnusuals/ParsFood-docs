import * as functions from "firebase-functions";

export const regionFunctions = functions.region("europe-west1");