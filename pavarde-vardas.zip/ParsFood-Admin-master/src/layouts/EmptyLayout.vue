<template>
    <v-app>
        <v-content>
            <slot/>
        </v-content>
    </v-app>
</template>