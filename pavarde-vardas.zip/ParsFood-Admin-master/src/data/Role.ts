export type Role = "admin" | "customer" | "provider_admin" | "provider_worker";
