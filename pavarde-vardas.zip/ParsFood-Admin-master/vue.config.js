module.exports = {
    lintOnSave: false,
    pluginOptions: {
        i18n: {
            enableInSFC: true
        }
    },
    transpileDependencies: [
        "vuetify"
    ]
};
